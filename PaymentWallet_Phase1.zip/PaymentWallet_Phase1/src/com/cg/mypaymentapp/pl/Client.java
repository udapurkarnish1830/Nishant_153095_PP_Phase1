package com.cg.mypaymentapp.pl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Scanner;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class Client
{
	private WalletService walletService;
	private HashMap<String, Customer> data;

	public Client()
	{
		data = new HashMap<>();
		walletService = new WalletServiceImpl(data);
	}

	public void menu()
	{
		System.out.println("");
		System.out.println("1. Create Account");
		System.out.println("2. Deposit Amount");
		System.out.println("3. Withdraw Amount");
		System.out.println("4. Fund Transfer ");
		System.out.println("5. Check Balance");
		System.out.println("0. Exit");
		System.out.println("Please choose an option -");
		Scanner scanner = new Scanner(System.in);

		int choice = scanner.nextInt();

		switch (choice)
		{
		case 1:
			
			System.out.println("Enter Name");
			String name = scanner.next();
			System.out.println("Enter Mobile Number");
			String mobileno = scanner.next();
			System.out.println("Enter Initial Balance to add");
			BigDecimal amount = scanner.nextBigDecimal();

			
			try
			{
				walletService.createAccount(name, mobileno, amount);
			}
			catch (Exception e4)
			{
				System.err.println(e4);
			}
			break;
			
		case 2:
			
			System.out.println("Enter MobileNo.");
			mobileno = scanner.next();
			System.out.println("Enter amount to deposit");
			amount = scanner.nextBigDecimal();

			try
			{
				walletService.depositAmount(mobileno, amount);
			}
			catch (Exception e3)
			{
				System.err.println(e3);
			}
			break;

		case 3:
			
			System.out.println("Enter MobileNo.");
			mobileno = scanner.next();
			System.out.println("Enter amount to withdraw deposit");
			amount = scanner.nextBigDecimal();

			try
			{
				walletService.withdrawAmount(mobileno, amount);
			}
			catch (Exception e2)
			{
				System.err.println(e2);
			}

			break;
			
		case 4:
			
			System.out.println("Enter source MobileNo.");
			String sourceMobileNo = scanner.next();
			System.out.println("Enter destination MobileNo.");
			String targetMobileNo = scanner.next();
			System.out.println("Enter amount to withdraw deposit");
			amount = scanner.nextBigDecimal();

			try
			{
				walletService.fundTransfer(sourceMobileNo, targetMobileNo, amount);
			}
			catch (Exception e1)
			{
				System.err.println(e1);
			}

			break;
			
		case 5:
			
			System.out.println("Enter mobile number to check balance");
			mobileno = scanner.next();

			try
			{
				Customer customer = walletService.showBalance(mobileno);

				System.out.println("Your balance is: " + customer.getWallet().getBalance());
			}
			catch (Exception e)
			{
				System.err.println(e);
			}
			
			break;
			
		default:
			
			System.exit(0);
			break;

		}

	}

	public static void main(String[] args) {

		Client client = new Client();

		while (true) {
			client.menu();
		}

	}
}
